/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Tres;

import Dos.MiColeccion;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;



public class pruebaColecciones {
    
    public static void main(String[] args){
    
    MiColeccion mc = new MiColeccion ();
    ArrayList al = new ArrayList (); 
    LinkedList ll = new LinkedList ();
    
        mc.add(1);
        mc.add(2);
        mc.add(3);
        
        System.out.println("Size: "+mc.size());
        System.out.println("Size: "+mc.isEmpty());

        al.add(1);
        al.add("Hola");
        al.add(3);

        ll.add(1);
        ll.add(2);
        ll.add(true);
        
        recorrerLista(ll);
        //mc no tiene implementado el metodo iterator por lo tanto for each no funciona
       // La ventajas son 1. si no especificas el tipo de datos puedes agregar cualquiera
       //2. con la funcion getclass().getname() puedes saber el tipo de dato y tomar accion sobre esto
    }
    
    public static void recorrerLista(List lista ){
    
        for (Object object : lista) {
           
            System.out.println("Tipo de Objeto: "+object.getClass().getName());
        }
        
    }
    
}
