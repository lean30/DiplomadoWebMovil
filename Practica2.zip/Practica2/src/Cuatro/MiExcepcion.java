/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Cuatro;

/**
 *
 * @author owner
 */
public class MiExcepcion extends Exception  {

    public MiExcepcion() {
    }

    public MiExcepcion(String message) {
        super(message);
    }
    
    
    
}
