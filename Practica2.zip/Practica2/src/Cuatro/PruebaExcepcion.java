/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Cuatro;

/**
 *
 * @author owner
 */
public class PruebaExcepcion {
    
    public static void disparandoExcepcion (int a, int b) throws MiExcepcion{
    
        if (a==0 || b ==0)
          throw new MiExcepcion("Not supported yet.");          
        
        
    
    } 
    
    public static void capturandoExcepcion (int c, int d) throws MiExcepcion {
    
        try {
           disparandoExcepcion(2,2); 
        } catch (MiExcepcion e) {
     
            System.out.println("Excepcion: "+e.getMessage());
            
        }
    
   
   
        
    
    }
    
}
