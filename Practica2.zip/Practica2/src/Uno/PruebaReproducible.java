/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Uno;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author owner
 */
public class PruebaReproducible {
    
    
    
    public static void main(String[] args) {
        // TODO code application logic here
        
        
        // Instanciar objetos de la clase Audio
        Audio audio1 = new Audio();
        Audio audio2 = new Audio();
        Audio audio3 = new Audio();
        
        // Instanciar objetos de la clase Video
        Video video1 = new Video();
        Video video2 = new Video();
        Video video3 = new Video();
        
        // Se crea una lista para agregar Objetos que implementen ReproductorMedia
        List<RepoductorMedia> listaReproductorMedia = new ArrayList<RepoductorMedia>();
        
        listaReproductorMedia.add(audio1);
        listaReproductorMedia.add(audio2);
        listaReproductorMedia.add(audio3);
        
        
        listaReproductorMedia.add(video1);
        listaReproductorMedia.add(video2);
        listaReproductorMedia.add(video3);
        
        // llamar metodo
        procesarRepoductoresMedia(listaReproductorMedia);

        
    }
    
    
    // Metodo que ejecuta los metodos de la interface ReproductorMedia
     static void procesarRepoductoresMedia ( List<RepoductorMedia> lista){
         
         // recorrer cada uno de los objetos en la lista y llamar todos sus metodos
         for (RepoductorMedia repoductorMedia : lista) {
             repoductorMedia.avanzar();
             repoductorMedia.detener();
             repoductorMedia.ejecutar();
             repoductorMedia.grabar();
             repoductorMedia.rebobinar();
         }
     }
    
}
