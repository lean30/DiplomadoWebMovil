/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package PracticaUno;

/**
 *
 * @author owner
 */
public class Mi_Clase {
    
   public static int miClase =0;
    private int valorClase = 0;

    public int getValorClase() {
        return valorClase;
    }

    public void setValorClase(int valorClase) {
        this.valorClase = valorClase;
    }

   
    public Mi_Clase() {
        
        miClase++;
    }
    
    
    
    
}
