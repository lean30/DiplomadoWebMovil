package PracticaUno;

/**
 *
 * @author owner
 */
public class Verificar {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
      
 System.out.println("Fundacion Codigo Libre");
 int a = 10;
 int b = 3;
 System.out.println("Datos a operar"+a+ " y b="+b);
 System.out.println("La multiplicacion vale a*b");
 int c = a+b;
 System.out.println("La suma es "+a+b);
 System.out.println(a+b+" tambien es la suma");
 System.out.println("O lo que es lo mismo "+c);
 c = a-b;
 System.out.println("La resta es "+c);
 System.out.println("La resta es tambien "+c);       


// TODO code application logic here
    }
    
}
