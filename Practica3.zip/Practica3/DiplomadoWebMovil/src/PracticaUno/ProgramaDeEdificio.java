/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package PracticaUno;

/**
 *
 * @author owner
 */
public class ProgramaDeEdificio {
    
   public static void main (String arg[]) {
   
   Edificio edificio1= new Edificio("Empire", 10, 9);
   
   edificio1.imprimirNombre();
       
   } 
    
}
