/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package PracticaUno;

/**
 *
 * @author owner
 */
public class ProgramaEstudiante {
    
    public static void main (String args[]) {
    
    Estudiante estudiante1=new Estudiante("Leandro", "Santiago", 20031066, 29);
    Estudiante estudiante2=new Estudiante("Cristiano", "Santiago", 20031066, 29);
    Estudiante estudiante3=new Estudiante("Benzema", "Santiago", 20031066, 29);
    Estudiante estudiante4=new Estudiante("Marcelo", "Santiago", 20031066, 29);
    Estudiante estudiante5=new Estudiante("Pepe", "Santiago", 20031066, 29);
    
    estudiante1.setNombre("Edgar");
    estudiante2.setApellido("Santiago");
    estudiante3.setMatricula(20001020);
    estudiante4.setEdad(20);
    
    
    
    }
    
    
}
