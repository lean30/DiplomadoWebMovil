/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practica3;

import java.io.IOException;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

/**
 *
 * @author owner
 */
public class Practica3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {

        String url = "http://www.facebook.com";
        System.out.println("Obteniendo datos desde la URL" + url);

        Document doc = Jsoup.connect(url).get();
               
        Elements lineas = doc.select("br");
        System.out.println("Cantidad de lineas: " + lineas.size());

        Elements parrafos = doc.select("p");
        System.out.println("Cantidad de Parrafos: " + parrafos.size());

        Elements imagenes = doc.select("img");
        System.out.println("Cantidad de Imagenes: " + imagenes.size());

        Elements formularios = doc.select("form");
        System.out.println("Cantidad de Formularios: " + formularios.size());

        Elements allInputFields = doc.getElementsByTag("input");

        for (Element form : formularios) {
            System.out.println("form: " + form.id());

            System.out.println("inputs: "+form.getElementsByTag("input"));

        }

        // TODO code application logic here
    }

}
